/**
 *@desc Class ${NAME}
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 *@version ${DATE} ${TIME}
 *@author YanHaI
 */
